function sendToSheet(qrtext){
  document.getElementById("status").innerHTML="Mengirim...";
  fetch(APP_URL, {
    method:"POST",
    body: JSON.stringify({
      token: WRITE_TOKEN,
      text: qrtext
    })
  })
  .then(r=>r.text())
  .then(t=>{
    document.getElementById("status").innerHTML="Terkirim: "+t;
  })
  .catch(e=>{
    document.getElementById("status").innerHTML="Error: "+e;
  });
}

function onScanSuccess(decodedText, decodedResult) {
  sendToSheet(decodedText);
}

let html5QrcodeScanner = new Html5QrcodeScanner(
  "reader", { fps: 10, qrbox: 250 });
html5QrcodeScanner.render(onScanSuccess);
